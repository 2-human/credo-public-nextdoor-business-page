Creatives are bundled here, organized by the campaign structure:

  creatives/<cluster>/<ad>/<ad>_<direction>_<ratio>.<ext>

  cluster    = ad group / utm_term  (validation | medical | credit-card)
  ad         = the ad / utm_content base
  direction  = illustration | photo | stilllife
  ratio      = 1x1 (1200x1200) | 1.91x1 (1200x628)

File <ad>_<direction> maps directly to utm_content <ad>-<direction>
(e.g. fdcpa-rights_photo_1x1.png -> utm_content=fdcpa-rights-photo).

These are local copies of the standard sets published on the
meta-ads-preview mirror; asset-manifest.csv (package root) lists the
canonical mirror URLs. Bold and 9:16 are intentionally excluded.
